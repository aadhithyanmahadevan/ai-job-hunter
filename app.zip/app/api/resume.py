from email.mime import text
from pathlib import Path
import os
import json
import traceback

from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    UploadFile,
    status,
)

from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user
from app.database.session import get_db

from app.database.resume_repository import ResumeRepository
from app.database.analysis_repository import AnalysisRepository

from app.models import resume
from app.models.resume import Resume
from app.models.resume_analysis import ResumeAnalysis
from app.models.user import User

from app.services.resume_service import ResumeService

router = APIRouter(
    prefix="/resume",
    tags=["Resume"],
)


# --------------------------------------------------------
# Upload Resume
# --------------------------------------------------------


@router.post("/upload")
async def upload_resume(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    try:

        filename, filepath = ResumeService.save_file(file)

        resume = Resume(
            user_id=current_user.id,
            filename=filename,
            file_path=filepath,
            extracted_text="",
            status="uploaded",
        )

        resume = ResumeRepository.create(db, resume)

        return {
            "success": True,
            "resume_id": resume.id,
            "filename": resume.filename,
            "message": "Resume uploaded successfully",
        }

    except Exception as e:

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e),
        )


# --------------------------------------------------------
# Analyze Resume
# --------------------------------------------------------


@router.post("/{resume_id}/analyze")
async def analyze_resume(
    resume_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    resume = ResumeRepository.get(db, resume_id)

    if not resume:

        raise HTTPException(
            status_code=404,
            detail="Resume not found",
        )

    if resume.user_id != current_user.id:

        raise HTTPException(
            status_code=403,
            detail="Unauthorized",
        )

    try:

        resume.status = "analyzing"
        ResumeRepository.update(db, resume)

        text = ResumeService.extract_resume(resume.file_path)

        resume.extracted_text = text
        ResumeRepository.update(db, resume)

        analysis_result = ResumeService.analyze_with_cache(text)

        resume.status = "completed"
        ResumeRepository.update(db, resume)

        analysis = ResumeAnalysis(
            resume_id=resume.id,
            ats_score=analysis_result.get("ats_score"),
            strengths=json.dumps(analysis_result.get("strengths", [])),
            missing_skills=json.dumps(analysis_result.get("missing_skills", [])),
            suggestions=json.dumps(analysis_result.get("suggestions", [])),
            raw_json=json.dumps(analysis_result),
        )

        AnalysisRepository.create(
            db,
            analysis,
        )

        return {
            "success": True,
            "resume_id": resume.id,
            "analysis": analysis_result,
        }

    except Exception as e:

        resume.status = "failed"
        ResumeRepository.update(db, resume)

        traceback.print_exc()

        raise HTTPException(
            status_code=500,
            detail=f"Resume analysis failed: {str(e)}",
    )


# --------------------------------------------------------
# Get All Resumes
# --------------------------------------------------------


@router.get("/")
def get_resumes(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    resumes = ResumeRepository.get_by_user(
        db,
        current_user.id,
    )

    return resumes


# --------------------------------------------------------
# Get Resume Details
# --------------------------------------------------------


@router.get("/{resume_id}")
def get_resume(
    resume_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    resume = ResumeRepository.get(
        db,
        resume_id,
    )

    if not resume:

        raise HTTPException(
            status_code=404,
            detail="Resume not found",
        )

    if resume.user_id != current_user.id:

        raise HTTPException(
            status_code=403,
            detail="Unauthorized",
        )

    analysis = AnalysisRepository.get_by_resume(
        db,
        resume.id,
    )

    return {
        "resume": resume,
        "analysis": analysis,
    }


# --------------------------------------------------------
# Delete Resume
# --------------------------------------------------------


@router.delete("/{resume_id}")
def delete_resume(
    resume_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):

    resume = ResumeRepository.get(
        db,
        resume_id,
    )

    if not resume:

        raise HTTPException(
            status_code=404,
            detail="Resume not found",
        )

    if resume.user_id != current_user.id:

        raise HTTPException(
            status_code=403,
            detail="Unauthorized",
        )

    if os.path.exists(resume.file_path):

        os.remove(resume.file_path)

    ResumeRepository.delete(
        db,
        resume,
    )

    return {
        "success": True,
        "message": "Resume deleted successfully",
    }
