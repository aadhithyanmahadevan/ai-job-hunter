from datetime import datetime

from pydantic import BaseModel, ConfigDict


class AnalysisResponse(BaseModel):
    id: int
    ats_score: int
    strengths: str
    missing_skills: str
    suggestions: str
    created_at: datetime

    model_config = ConfigDict(
        from_attributes=True
    )