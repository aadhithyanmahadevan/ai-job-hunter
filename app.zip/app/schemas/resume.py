from datetime import datetime

from pydantic import BaseModel, ConfigDict


class ResumeResponse(BaseModel):
    id: int
    filename: str
    uploaded_at: datetime

    model_config = ConfigDict(
        from_attributes=True
    )


class ResumeDetail(BaseModel):
    id: int
    filename: str
    extracted_text: str
    uploaded_at: datetime

    model_config = ConfigDict(
        from_attributes=True
    )